import static org.junit.Assert.*;
import org.junit.Test;

import java.lang.reflect.Method;
import jobsearchportal.EmployeeProfile;

public class EmployeeProfileTest {
    @Test
    public void testCreateProfileBtnActionPerformed() {
        try {
            EmployeeProfile employeeProfile = new EmployeeProfile();
            // Set values using your setter methods

            // Use reflection to access the private method
            Method method = EmployeeProfile.class.getDeclaredMethod("CreateProfileBtnActionPerformed", java.awt.event.ActionEvent.class);
            method.setAccessible(true);
            method.invoke(employeeProfile, (java.awt.event.ActionEvent) null);

            // Assertions and checks here
            assertEquals("Employee Profile has been created successfully!", employeeProfile.getDialogMessage());
        } catch (Exception e) {
            fail("Exception during test: " + e.getMessage());
        }
    }
}
//This will execute the testCreateProfileBtnActionPerformed method and verify if the profile
//creation behaves as expected.