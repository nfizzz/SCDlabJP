import jobsearchportal.Registration;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class RegistrationTest {

    @Test
    public void testIsValidEmail() {
        // Arrange
        Registration registration = new Registration();

        // Act and Assert for isValidEmail
        assertTrue(registration.isValidEmail("valid@example.com"));
        assertTrue(registration.isValidEmail("user123@gmail.com"));
        assertTrue(registration.isValidEmail("john.doe@company.org"));

        assertFalse(registration.isValidEmail("invalid-email"));
        assertFalse(registration.isValidEmail("missing@dotcom"));
        assertFalse(registration.isValidEmail("user@.com"));
    }

    @Test
    public void testIsValidPassword() {
        // Arrange
        Registration registration = new Registration();

        // Act and Assert for isValidPassword
        assertTrue(registration.isValidPassword("Strong@Pass123"));
        assertTrue(registration.isValidPassword("P@ssw0rd123"));

        assertFalse(registration.isValidPassword("weakpass"));
        assertFalse(registration.isValidPassword("password"));
        assertFalse(registration.isValidPassword("12345678"));
        assertFalse(registration.isValidPassword("NoSpecialChar1"));
        assertFalse(registration.isValidPassword("OnlyLowercaseletters"));
    }

    @Test
    public void testRegBtnActionPerformed() {
        // Arrange
        Registration registration = new Registration();

        // Act
        // ... (your existing test cases for RegBtnActionPerformed)
    }
}
