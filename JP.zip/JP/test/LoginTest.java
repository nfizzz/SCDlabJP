import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import jobsearchportal.Login;

/**
 *
 * @author user
 */
public class LoginTest {
    
    @Test
    public void testIsValidEmail() {
        Login login = new Login();

        // Valid email
        assertTrue(login.isValidEmail("test@example.com"));

        // Invalid email
        assertFalse(login.isValidEmail("invalid-email"));

        // Another valid email
        assertTrue(login.isValidEmail("user123@gmail.com"));
    }

    @Test
    public void testIsValidPassword() {
        Login login = new Login();

        // Valid password
        assertTrue(login.isValidPassword("StrongP@ss1"));

        // Invalid password (less than 8 characters)
        assertFalse(login.isValidPassword("Weak123"));

        // Invalid password (missing uppercase letter)
        assertFalse(login.isValidPassword("weakpassword@1"));

        // Invalid password (missing special character)
        assertFalse(login.isValidPassword("Weakpassword1"));

        // Another valid password
        assertTrue(login.isValidPassword("AnotherStrongP@ssword1"));
    }
    
}
