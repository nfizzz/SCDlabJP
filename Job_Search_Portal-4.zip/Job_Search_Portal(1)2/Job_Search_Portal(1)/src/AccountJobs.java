/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NOCS
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class AccountJobs extends javax.swing.JFrame implements Interface{

    /**
     * Creates new form AccountJobs
     */
    String jt,c;
    int d_jobnum1,d_jobnum2,d_jobnum3;
    
    
    String occupation_1,occupation_2,occupation_3="";
    String companyname_1,companyname_2,companyname_3="";
    String loc_1,loc_2,loc_3="";
    String sal_1,sal_2,sal_3="";
    String dline_1,dline_2,dline_3="";
    String type_1,type_2,type_3="";
    
    public AccountJobs() {
        initComponents();
        retrive_data2();
    }
    
    public AccountJobs(String jt,String c) {
        initComponents();
        this.jt=jt;
        this.c=c;
        System.out.println("Accountjob portal="+this.jt+this.c);
         retrive_data();
    }

        public void x()
    {
       this.setVisible(true);
    }
    
    String job_title = ""; // Initialize these variables here
    String c_name = "";
    String location="";
    String job_type="";
    String salary = "";
    String deadline = "";
    String d_jobnum="";
   
public void retrive_data() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline, job_num FROM accountjobs WHERE Title LIKE '%" + jt + "%'");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                 
                occupation1.setText(job_title);
                companyname1.setText(c_name);
                loc1.setText(location);
                salary1.setText(salary);
                deadline_date1.setText(deadline);
                type1.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
 
            } else if (rowIndex == 2) {
                
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                
                occupation2.setText(job_title);
                companyname2.setText(c_name);
                loc2.setText(location);
                salary2.setText(salary);
                deadline_date2.setText(deadline);
                type2.setText(job_type);
                d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                    
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;    
                    
                occupation3.setText(job_title);
                companyname3.setText(c_name);
                loc3.setText(location);
                salary3.setText(salary);
                deadline_date3.setText(deadline);
                type3.setText(job_type);
                d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

 public void retrive_data2() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline, job_num FROM accountjobs");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                
                occupation1.setText(job_title);
                companyname1.setText(c_name);
                loc1.setText(location);
                salary1.setText(salary);
                deadline_date1.setText(deadline);
                type1.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
 
            } else if (rowIndex == 2) {
                
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                
                
                occupation2.setText(job_title);
                companyname2.setText(c_name);
                loc2.setText(location);
                salary2.setText(salary);
                deadline_date2.setText(deadline);
                type2.setText(job_type);
                d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                    
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;    
                    
                occupation3.setText(job_title);
                companyname3.setText(c_name);
                loc3.setText(location);
                salary3.setText(salary);
                deadline_date3.setText(deadline);
                type3.setText(job_type);
                d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        penal3 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        explorebutton4 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        occupation1 = new javax.swing.JTextField();
        companyname1 = new javax.swing.JTextField();
        salary1 = new javax.swing.JTextField();
        deadline_date1 = new javax.swing.JTextField();
        type1 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        loc1 = new javax.swing.JTextField();
        Backbutton = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        explorebutton5 = new javax.swing.JButton();
        jLabel67 = new javax.swing.JLabel();
        occupation2 = new javax.swing.JTextField();
        companyname2 = new javax.swing.JTextField();
        salary2 = new javax.swing.JTextField();
        deadline_date2 = new javax.swing.JTextField();
        type2 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        loc2 = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        explorebutton6 = new javax.swing.JButton();
        jLabel68 = new javax.swing.JLabel();
        occupation3 = new javax.swing.JTextField();
        companyname3 = new javax.swing.JTextField();
        salary3 = new javax.swing.JTextField();
        deadline_date3 = new javax.swing.JTextField();
        type3 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        loc3 = new javax.swing.JTextField();
        setNotification_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        penal3.setBackground(new java.awt.Color(0, 51, 51));

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));

        jLabel58.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(102, 102, 102));
        jLabel58.setText("Salary:");

        jLabel59.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(102, 102, 102));
        jLabel59.setText("Deadline:");

        explorebutton4.setText("Explore");
        explorebutton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton4ActionPerformed(evt);
            }
        });

        jLabel40.setText("jLabel37");

        occupation1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation1.setText("Software Engineer");
        occupation1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation1ActionPerformed(evt);
            }
        });

        companyname1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname1.setForeground(new java.awt.Color(102, 102, 255));
        companyname1.setText("Pythonleads");
        companyname1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname1ActionPerformed(evt);
            }
        });

        salary1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary1.setText("Rs 70,000 - 100,000 a month");
        salary1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary1ActionPerformed(evt);
            }
        });

        deadline_date1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date1.setText("5 April 2023");

        type1.setBackground(new java.awt.Color(0, 153, 153));
        type1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type1.setText("Full-time");

        jTextField9.setBackground(new java.awt.Color(0, 153, 153));
        jTextField9.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField9.setText("Remote");

        loc1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc1.setForeground(new java.awt.Color(102, 102, 102));
        loc1.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel59))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                                .addComponent(loc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(occupation1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel58)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(companyname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton4)))
                .addGap(265, 265, 265))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel58))
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton4))))
                    .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel40)
                        .addGroup(jPanel25Layout.createSequentialGroup()
                            .addComponent(companyname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        Backbutton.setBackground(new java.awt.Color(0, 153, 153));
        Backbutton.setText("BACK");
        Backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbuttonActionPerformed(evt);
            }
        });

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        jLabel43.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(102, 102, 102));
        jLabel43.setText("Salary:");

        jLabel44.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(102, 102, 102));
        jLabel44.setText("Deadline:");

        explorebutton5.setText("Explore");
        explorebutton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton5ActionPerformed(evt);
            }
        });

        jLabel67.setText("jLabel37");

        occupation2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation2.setText("Software Engineer");
        occupation2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation2ActionPerformed(evt);
            }
        });

        companyname2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname2.setForeground(new java.awt.Color(102, 102, 255));
        companyname2.setText("Pythonleads");
        companyname2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname2ActionPerformed(evt);
            }
        });

        salary2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary2.setText("Rs 70,000 - 100,000 a month");
        salary2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary2ActionPerformed(evt);
            }
        });

        deadline_date2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date2.setText("5 April 2023");

        type2.setBackground(new java.awt.Color(0, 153, 153));
        type2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type2.setText("Full-time");

        jTextField13.setBackground(new java.awt.Color(0, 153, 153));
        jTextField13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField13.setText("Remote");

        loc2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc2.setForeground(new java.awt.Color(102, 102, 102));
        loc2.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel44))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(loc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(occupation2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel43)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(companyname2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton5)))
                .addGap(265, 265, 265))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton5))))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel67)
                        .addGroup(jPanel15Layout.createSequentialGroup()
                            .addComponent(companyname2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));

        jLabel45.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(102, 102, 102));
        jLabel45.setText("Salary:");

        jLabel46.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(102, 102, 102));
        jLabel46.setText("Deadline:");

        explorebutton6.setText("Explore");
        explorebutton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton6ActionPerformed(evt);
            }
        });

        jLabel68.setText("jLabel37");

        occupation3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation3.setText("Software Engineer");
        occupation3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation3ActionPerformed(evt);
            }
        });

        companyname3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname3.setForeground(new java.awt.Color(102, 102, 255));
        companyname3.setText("Pythonleads");
        companyname3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname3ActionPerformed(evt);
            }
        });

        salary3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary3.setText("Rs 70,000 - 100,000 a month");
        salary3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary3ActionPerformed(evt);
            }
        });

        deadline_date3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date3.setText("5 April 2023");

        type3.setBackground(new java.awt.Color(0, 153, 153));
        type3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type3.setText("Full-time");

        jTextField20.setBackground(new java.awt.Color(0, 153, 153));
        jTextField20.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField20.setText("Remote");

        loc3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc3.setForeground(new java.awt.Color(102, 102, 102));
        loc3.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel68, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel46))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                                .addComponent(loc3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(occupation3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel45)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(companyname3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton6)))
                .addGap(265, 265, 265))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45))
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton6))))
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel68)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(companyname3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 17, Short.MAX_VALUE))
        );

        setNotification_Button.setText("SET NOTIFICATION");
        setNotification_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setNotification_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout penal3Layout = new javax.swing.GroupLayout(penal3);
        penal3.setLayout(penal3Layout);
        penal3Layout.setHorizontalGroup(
            penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penal3Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(penal3Layout.createSequentialGroup()
                        .addComponent(setNotification_Button)
                        .addGap(463, 463, 463)
                        .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        penal3Layout.setVerticalGroup(
            penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, penal3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(setNotification_Button))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(124, 124, 124))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(penal3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(penal3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void explorebutton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton4ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Account & Finance",occupation_1,companyname_1,loc_1,sal_1,dline_1,type_1,d_jobnum1);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton4ActionPerformed

    private void occupation1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation1ActionPerformed

    private void companyname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname1ActionPerformed

    private void salary1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary1ActionPerformed

    private void BackbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbuttonActionPerformed
        // TODO add your handling code here:
        Search s=new Search();
        s.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackbuttonActionPerformed

    private void explorebutton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton5ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Account & Finance",occupation_2,companyname_2,loc_2,sal_2,dline_2,type_2,d_jobnum2);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton5ActionPerformed

    private void occupation2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation2ActionPerformed

    private void companyname2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname2ActionPerformed

    private void salary2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary2ActionPerformed

    private void explorebutton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton6ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Account & Finance",occupation_3,companyname_3,loc_3,sal_3,dline_3,type_3,d_jobnum3);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton6ActionPerformed

    private void occupation3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation3ActionPerformed

    private void companyname3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname3ActionPerformed

    private void salary3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary3ActionPerformed

    private void setNotification_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setNotification_ButtonActionPerformed
        // TODO add your handling code here:
        DB_Connectivity db;
        db = DB_Connectivity.getobject();
        Connection con = db.DbConnection();
//        UserSubscription userSubscription=new UserSubscription(user_id,"technology");
        
        try {
            PreparedStatement pst=con.prepareStatement("INSERT INTO notifi_table (category,email_id,name) VALUES (?,?,?)");
            pst.setString(1,Jcategory);
            pst.setString(2,);
            pst.setString(3,);
            
                
            pst.executeUpdate();
            System.out.println("User added to notification table");
            
        }catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_setNotification_ButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccountJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccountJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccountJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccountJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccountJobs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbutton;
    private javax.swing.JTextField companyname1;
    private javax.swing.JTextField companyname2;
    private javax.swing.JTextField companyname3;
    private javax.swing.JTextField deadline_date1;
    private javax.swing.JTextField deadline_date2;
    private javax.swing.JTextField deadline_date3;
    private javax.swing.JButton explorebutton4;
    private javax.swing.JButton explorebutton5;
    private javax.swing.JButton explorebutton6;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JTextField loc1;
    private javax.swing.JTextField loc2;
    private javax.swing.JTextField loc3;
    private javax.swing.JTextField occupation1;
    private javax.swing.JTextField occupation2;
    private javax.swing.JTextField occupation3;
    private javax.swing.JPanel penal3;
    private javax.swing.JTextField salary1;
    private javax.swing.JTextField salary2;
    private javax.swing.JTextField salary3;
    private javax.swing.JButton setNotification_Button;
    private javax.swing.JTextField type1;
    private javax.swing.JTextField type2;
    private javax.swing.JTextField type3;
    // End of variables declaration//GEN-END:variables
}
