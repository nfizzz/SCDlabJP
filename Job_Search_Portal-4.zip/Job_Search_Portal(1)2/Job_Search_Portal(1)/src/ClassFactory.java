/*
 * 
 */
public abstract class ClassFactory {
    public abstract Interface getObject(String ObjectType);
}

class Factory extends ClassFactory
{
    public Interface getObject(String Type){
        if(Type == null)
    {
        return null;
    }
    if(Type.equalsIgnoreCase("Technology")){
        return new TechJobs();
    } 
    else if(Type.equalsIgnoreCase("account"))
    {
        return new AccountJobs();
    } 
    else if(Type.equalsIgnoreCase("medical"))
    {
        return new MedicalJobs();
    }
    
    return null;
    }
    
}