import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;


public class DB_Connectivity {
    private static  DB_Connectivity db ;
    Connection con;
    
    private DB_Connectivity(){
        
    }
    public static DB_Connectivity getobject(){
        if(db==null){
            db=new DB_Connectivity();
        }
        return db;
    }
    public Connection DbConnection() {
    try {
        Class.forName("com.mysql.jdbc.Driver");
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/job?zeroDateTimeBehavior=convertToNull", "root", "");
            System.out.println("connected to db");
        } catch (Exception e) {
            System.out.println(e);
        }
    } catch (Exception e) {
        System.out.println(e);
    }
    return con;
}
    
// retrieving the subscribed users into list     
    public List<UserSubscription> getSubscribedUsers(String category) 
    
    {
        List<UserSubscription> subscribedUsers = new ArrayList<>();
        try {
            Connection con = DbConnection();
            Statement sm = con.createStatement();
            ResultSet rs = sm.executeQuery("SELECT user_id, category FROM subscribers WHERE category ='"+category+"'");
            
                while (rs.next())
                {
                        int userId = rs.getInt("user_id");
                        String subscribedCategory = rs.getString("category");
                        UserSubscription userSubscription = new UserSubscription(userId, subscribedCategory);
                        subscribedUsers.add(userSubscription);
                }
                
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return subscribedUsers;
    }
} 
    

