/*
 *
 */
public interface Interface {
    public void x();
}
