import java.sql.Connection;
import java.sql.PreparedStatement;

import java.util.ArrayList;
import java.util.List;


public interface JobObserver {
    void update(JobPosting job);

    void subscribe(UserSubscription userSubscription);

    void unsubscribe(UserSubscription userSubscription);
}



 class JobPosting {
    private String category;
    private String title;

    public JobPosting(String category, String title) {
        this.category = category;
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public String getTitle() {
        return title;
    }
 }


 class UserSubscription implements JobObserver {
    private int user_id;
    private String subscribedCategory;

    // Additional data structure to store subscribers
    private List<UserSubscription> subscribers;

    public UserSubscription(int user_id, String subscribedCategory) {
        this.user_id = user_id;
        this.subscribedCategory = subscribedCategory;
        this.subscribers = new ArrayList<>();
    }

    @Override
    public void update(JobPosting job) {
        System.out.println("Notification for user " + user_id + ": New job posted in " +
                subscribedCategory + " category - " + job.getTitle());
    }

    // Additional method to subscribe a user
    public void subscribe(UserSubscription userSubscription) {
        subscribers.add(userSubscription);
    }

    // Additional method to unsubscribe a user
    public void unsubscribe(UserSubscription userSubscription) {
        subscribers.remove(userSubscription);
    }

    // Additional method to notify all subscribers about a job update
    public void notifySubscribers(JobPosting job) {
        for (UserSubscription subscriber : subscribers) {
            subscriber.update(job);
        }
    }

    // Additional method to get user ID
    public int getUserId() {
        return user_id;
    }

    // Additional method to get subscribed category
    public String getSubscribedCategory() {
        return subscribedCategory;
    }
}


