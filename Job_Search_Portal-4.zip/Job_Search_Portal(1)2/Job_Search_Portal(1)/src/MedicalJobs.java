/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NOCS
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class MedicalJobs extends javax.swing.JFrame implements Interface{

    /**
     * Creates new form MedicalJobs
     */
    String jt,c;
    int d_jobnum1,d_jobnum2,d_jobnum3;
    
    String occupation_1,occupation_2,occupation_3="";
    String companyname_1,companyname_2,companyname_3="";
    String loc_1,loc_2,loc_3="";
    String sal_1,sal_2,sal_3="";
    String dline_1,dline_2,dline_3="";
    String type_1,type_2,type_3="";
    
    public MedicalJobs() {
        initComponents();
        retrive_data2();
    }
    
    public MedicalJobs(String jt,String c) {
        initComponents();
        this.jt=jt;
        this.c=c;
        System.out.println("medicaljob portal="+this.jt+this.c);
        retrive_data();
    }
  
    
        public void x()
    {
       this.setVisible(true);
    }
    
   String job_title = ""; // Initialize these variables here
    String c_name = "";
    String location="";
    String job_type="";
    String salary = "";
    String deadline = "";
    String d_jobnum="";
   
public void retrive_data() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline, job_num FROM medicaljobs WHERE Title LIKE '%" + jt + "%'");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);
            

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                 
                occupation11.setText(job_title);
                companyname11.setText(c_name);
                loc11.setText(location);
                salary11.setText(salary);
                deadline_date11.setText(deadline);
                type11.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
 
            } else if (rowIndex == 2) {
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                 
                occupation12.setText(job_title);
                companyname12.setText(c_name);
                loc12.setText(location);
                salary12.setText(salary);
                deadline_date12.setText(deadline);
                type12.setText(job_type);
                d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                    
                    
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;  
                 
                occupation13.setText(job_title);
                companyname13.setText(c_name);
                loc13.setText(location);
                salary13.setText(salary);
                deadline_date13.setText(deadline);
                type13.setText(job_type);
                 d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

 public void retrive_data2() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline, job_num FROM medicaljobs");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);
            

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                
                occupation11.setText(job_title);
                companyname11.setText(c_name);
                loc11.setText(location);
                salary11.setText(salary);
                deadline_date11.setText(deadline);
                type11.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
 
            } else if (rowIndex == 2) {
                
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                 
                occupation12.setText(job_title);
                companyname12.setText(c_name);
                loc12.setText(location);
                salary12.setText(salary);
                deadline_date12.setText(deadline);
                type12.setText(job_type);
                d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;  
                    
                occupation13.setText(job_title);
                companyname13.setText(c_name);
                loc13.setText(location);
                salary13.setText(salary);
                deadline_date13.setText(deadline);
                type13.setText(job_type);
                 d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        penal3 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        explorebutton4 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        occupation11 = new javax.swing.JTextField();
        companyname11 = new javax.swing.JTextField();
        salary11 = new javax.swing.JTextField();
        deadline_date11 = new javax.swing.JTextField();
        type11 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        loc11 = new javax.swing.JTextField();
        Backbutton = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        explorebutton5 = new javax.swing.JButton();
        jLabel67 = new javax.swing.JLabel();
        occupation12 = new javax.swing.JTextField();
        companyname12 = new javax.swing.JTextField();
        salary12 = new javax.swing.JTextField();
        deadline_date12 = new javax.swing.JTextField();
        type12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        loc12 = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        explorebutton6 = new javax.swing.JButton();
        jLabel68 = new javax.swing.JLabel();
        occupation13 = new javax.swing.JTextField();
        companyname13 = new javax.swing.JTextField();
        salary13 = new javax.swing.JTextField();
        deadline_date13 = new javax.swing.JTextField();
        type13 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        loc13 = new javax.swing.JTextField();
        SetNotificatiion_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        penal3.setBackground(new java.awt.Color(0, 51, 51));

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));

        jLabel58.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(102, 102, 102));
        jLabel58.setText("Salary:");

        jLabel59.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(102, 102, 102));
        jLabel59.setText("Deadline:");

        explorebutton4.setText("Explore");
        explorebutton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton4ActionPerformed(evt);
            }
        });

        jLabel40.setText("jLabel37");

        occupation11.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation11.setText("Software Engineer");
        occupation11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation11ActionPerformed(evt);
            }
        });

        companyname11.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname11.setForeground(new java.awt.Color(102, 102, 255));
        companyname11.setText("Pythonleads");
        companyname11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname11ActionPerformed(evt);
            }
        });

        salary11.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary11.setText("Rs 70,000 - 100,000 a month");
        salary11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary11ActionPerformed(evt);
            }
        });

        deadline_date11.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date11.setText("5 April 2023");

        type11.setBackground(new java.awt.Color(0, 153, 153));
        type11.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type11.setText("Full-time");

        jTextField9.setBackground(new java.awt.Color(0, 153, 153));
        jTextField9.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField9.setText("Remote");

        loc11.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc11.setForeground(new java.awt.Color(102, 102, 102));
        loc11.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel59))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                                .addComponent(loc11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(occupation11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel58)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(companyname11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton4)))
                .addGap(265, 265, 265))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel58))
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton4))))
                    .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel40)
                        .addGroup(jPanel25Layout.createSequentialGroup()
                            .addComponent(companyname11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        Backbutton.setBackground(new java.awt.Color(0, 153, 153));
        Backbutton.setText("BACK");
        Backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbuttonActionPerformed(evt);
            }
        });

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        jLabel43.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(102, 102, 102));
        jLabel43.setText("Salary:");

        jLabel44.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(102, 102, 102));
        jLabel44.setText("Deadline:");

        explorebutton5.setText("Explore");
        explorebutton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton5ActionPerformed(evt);
            }
        });

        jLabel67.setText("jLabel37");

        occupation12.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation12.setText("Software Engineer");
        occupation12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation12ActionPerformed(evt);
            }
        });

        companyname12.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname12.setForeground(new java.awt.Color(102, 102, 255));
        companyname12.setText("Pythonleads");
        companyname12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname12ActionPerformed(evt);
            }
        });

        salary12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary12.setText("Rs 70,000 - 100,000 a month");
        salary12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary12ActionPerformed(evt);
            }
        });

        deadline_date12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date12.setText("5 April 2023");

        type12.setBackground(new java.awt.Color(0, 153, 153));
        type12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type12.setText("Full-time");

        jTextField13.setBackground(new java.awt.Color(0, 153, 153));
        jTextField13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField13.setText("Remote");

        loc12.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc12.setForeground(new java.awt.Color(102, 102, 102));
        loc12.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel44))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(loc12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(occupation12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel43)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(companyname12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton5)))
                .addGap(265, 265, 265))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton5))))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel67)
                        .addGroup(jPanel15Layout.createSequentialGroup()
                            .addComponent(companyname12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));

        jLabel45.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(102, 102, 102));
        jLabel45.setText("Salary:");

        jLabel46.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(102, 102, 102));
        jLabel46.setText("Deadline:");

        explorebutton6.setText("Explore");
        explorebutton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton6ActionPerformed(evt);
            }
        });

        jLabel68.setText("jLabel37");

        occupation13.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation13.setText("Software Engineer");
        occupation13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation13ActionPerformed(evt);
            }
        });

        companyname13.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname13.setForeground(new java.awt.Color(102, 102, 255));
        companyname13.setText("Pythonleads");
        companyname13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname13ActionPerformed(evt);
            }
        });

        salary13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary13.setText("Rs 70,000 - 100,000 a month");
        salary13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary13ActionPerformed(evt);
            }
        });

        deadline_date13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date13.setText("5 April 2023");

        type13.setBackground(new java.awt.Color(0, 153, 153));
        type13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type13.setText("Full-time");

        jTextField20.setBackground(new java.awt.Color(0, 153, 153));
        jTextField20.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField20.setText("Remote");

        loc13.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc13.setForeground(new java.awt.Color(102, 102, 102));
        loc13.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel68, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel46))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                                .addComponent(loc13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(occupation13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel45)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(companyname13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton6)))
                .addGap(265, 265, 265))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45))
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton6))))
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel68)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(companyname13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 17, Short.MAX_VALUE))
        );

        SetNotificatiion_Button.setText("SET NOTIFICATION");
        SetNotificatiion_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SetNotificatiion_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout penal3Layout = new javax.swing.GroupLayout(penal3);
        penal3.setLayout(penal3Layout);
        penal3Layout.setHorizontalGroup(
            penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penal3Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(penal3Layout.createSequentialGroup()
                        .addComponent(SetNotificatiion_Button)
                        .addGap(463, 463, 463)
                        .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        penal3Layout.setVerticalGroup(
            penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, penal3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(penal3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SetNotificatiion_Button))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(124, 124, 124))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(penal3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(penal3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void explorebutton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton4ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Medical & Nurse",occupation_1,companyname_1,loc_1,sal_1,dline_1,type_1,d_jobnum1);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton4ActionPerformed

    private void occupation11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation11ActionPerformed

    private void companyname11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname11ActionPerformed

    private void salary11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary11ActionPerformed

    private void BackbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbuttonActionPerformed
        // TODO add your handling code here:
        Search s=new Search();
        s.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackbuttonActionPerformed

    private void explorebutton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton5ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Medical & Nurse",occupation_2,companyname_2,loc_2,sal_2,dline_2,type_2,d_jobnum2);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton5ActionPerformed

    private void occupation12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation12ActionPerformed

    private void companyname12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname12ActionPerformed

    private void salary12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary12ActionPerformed

    private void explorebutton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton6ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Medical & Nurse",occupation_3,companyname_3,loc_3,sal_3,dline_3,type_3,d_jobnum3);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton6ActionPerformed

    private void occupation13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation13ActionPerformed

    private void companyname13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname13ActionPerformed

    private void salary13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary13ActionPerformed

    private void SetNotificatiion_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SetNotificatiion_ButtonActionPerformed
        // TODO add your handling code here:
        DB_Connectivity db;
        db = DB_Connectivity.getobject();
        Connection con = db.DbConnection();
//        UserSubscription userSubscription=new UserSubscription(user_id,"technology");
        
        try {
            PreparedStatement pst=con.prepareStatement("INSERT INTO notifi_table (category,email_id,name) VALUES (?,?,?)");
            pst.setString(1,Jcategory);
            pst.setString(2,);
            pst.setString(3,);
            
                
            pst.executeUpdate();
            System.out.println("User added to notification table");
            
        }catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_SetNotificatiion_ButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MedicalJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MedicalJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MedicalJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MedicalJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MedicalJobs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbutton;
    private javax.swing.JButton SetNotificatiion_Button;
    private javax.swing.JTextField companyname11;
    private javax.swing.JTextField companyname12;
    private javax.swing.JTextField companyname13;
    private javax.swing.JTextField deadline_date11;
    private javax.swing.JTextField deadline_date12;
    private javax.swing.JTextField deadline_date13;
    private javax.swing.JButton explorebutton4;
    private javax.swing.JButton explorebutton5;
    private javax.swing.JButton explorebutton6;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JTextField loc11;
    private javax.swing.JTextField loc12;
    private javax.swing.JTextField loc13;
    private javax.swing.JTextField occupation11;
    private javax.swing.JTextField occupation12;
    private javax.swing.JTextField occupation13;
    private javax.swing.JPanel penal3;
    private javax.swing.JTextField salary11;
    private javax.swing.JTextField salary12;
    private javax.swing.JTextField salary13;
    private javax.swing.JTextField type11;
    private javax.swing.JTextField type12;
    private javax.swing.JTextField type13;
    // End of variables declaration//GEN-END:variables
}
