
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Notification_1 {
    String Notifi_Table,N_Category;
    public Notification_1(String Job_Tablename)
    {
        this.N_Category=Job_Tablename;
      // N_Category="techjobs";

      retrive_data(N_Category); // uncomment it
     //EmailSender("izmanajeebwc@gmail.com","izma");   // delete it
    }
    public void retrive_data(String Notifi_Table)
    {
          DB_Connectivity db;
          db = DB_Connectivity.getobject();
          Connection con = db.DbConnection();
          
              Statement sm = null;
              ResultSet rs = null;
          try {
           sm = con.createStatement();
           rs = sm.executeQuery("SELECT email_id,name FROM Notifi_Table WHERE category = '" + N_Category + "'"); 
          
          // Traverse the result set
            while (rs.next()) {
                // Retrieve and print the email ID
                String email_id = rs.getString("email_id");
                String name= rs.getString("name");
                System.out.println("Email ID: " + email_id + "UserName: "+ name);
            
                EmailSender(email_id,name);
                
            }
          }
          catch(Exception e)
         {
          System.out.println(e);
         }
          finally {
        // Close the ResultSet and Statement in the finally block to ensure they are always closed
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (sm != null) {
            try {
                sm.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
          }
    }
    
    public void EmailSender(String email_id, String name)
    {
        System.out.println(email_id+name);
        String E_Category = null;
        try {
            if("techjobs".equals(N_Category))
            {
                E_Category="Tech&Development";
            }
            else if("accountjobs".equals(N_Category))
            {
                E_Category="Account&Finance";    
            }
            else if("medicaljobs".equals(N_Category))
            {
                E_Category="Medical&Nurse";
            }
        // Specify your email subject and message
        String subject = "New Job Alert: "+ E_Category + " jobs Opportunity Now Available!";   //email subject
        String message = "Dear "+ name +",\n" +"\n" + "We hope this message finds you well in your job search journey. We are excited to inform you that a new job opportunity in the "+ E_Category + " field has just been posted on our job portal";  // email message

            System.out.println(subject+message);
        
        
        // Create GMailer object and send email
        Notification_GMail2 mailer = new Notification_GMail2();
        mailer.sendMail(email_id, subject, message);
    } catch (Exception e) {
        System.out.println("Error sending email: " + e.getMessage());
    }
    }
    
//    public static void main(String[] args)
//{
//    Notification ob= new Notification("techjobs");
//    
//}
    
    
}
