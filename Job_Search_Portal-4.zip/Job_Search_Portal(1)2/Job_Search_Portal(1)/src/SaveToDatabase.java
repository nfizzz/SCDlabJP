
import java.sql.Connection;
import java.sql.PreparedStatement;

//public class JobPost_Multithreading {

    public class SaveToDatabase implements Runnable {        
    String title,company_name,location,Job_type,Salary,Deadline,Description,Responsibility;
    String education,skills,exprience,instructions,Job_Tablename,JobDesc_Tablename;
    
    public SaveToDatabase(String title, String company_name,String location ,String Job_type,String Salary,String Deadline,String Description,String Responsibility,String education,String skills,String exprience,String instructions,String Job_Tablename,String JobDesc_Tablename)
    {
        this.title=title;
        this.company_name=company_name;
        this.location=location;
        this.Job_type=Job_type;
        this.Salary=Salary;
        this.Deadline=Deadline;
        this.Description=Description;
        this.Responsibility=Responsibility;
        
        this.education=education;
        this.skills=skills;
        this.exprience=exprience;
        this.instructions=instructions;
        this.Job_Tablename=Job_Tablename;
        this.JobDesc_Tablename=JobDesc_Tablename;
        
    }
    @Override
    public void run() {
         DB_Connectivity db;
         db=DB_Connectivity.getobject();
         Connection con=db.DbConnection();
         try{ 
          
        PreparedStatement pst=con.prepareStatement("INSERT INTO " + Job_Tablename + "(Title,company,location,job_type,salary,deadline) VALUES (?,?,?,?,?,?)");
        pst.setString(1,title);
        pst.setString(2,company_name);
        pst.setString(3,location);
        pst.setString(4,Job_type);
        pst.setString(5,Salary);
        pst.setString(6,Deadline);
        pst.executeUpdate();
        System.out.println("data inserted into job_table="+Job_Tablename);
     
        PreparedStatement pst2=con.prepareStatement("INSERT INTO " + JobDesc_Tablename + "(JobDescription,Responsibility,EduReq,Skills,Experience,instruction) VALUES (?,?,?,?,?,?)");
        pst2.setString(1,Description);
        pst2.setString(2,Responsibility);
        pst2.setString(3,education);
        pst2.setString(4,skills);
        pst2.setString(5,exprience);
        pst2.setString(6,instructions);
        pst2.executeUpdate();
        System.out.println("data inserted into job_Description_table="+JobDesc_Tablename);
       // jLabel1.setText("Job Posted");
     
         con.close();
         }
        catch(Exception e)
      {
          System.out.println(e);
      }

    }
}

//    class SendNotification implements Runnable {
//        String category;
//        SendNotification(String Job_Tablename)
//        {
//            this.category=Job_Tablename;
//        }
//    
//    @Override
//    public void run() {
//        Notification ob= new Notification(category);
//    }
//}    
    
    
 //   public static void main(String[] args) {
        // Create instances of the tasks
//        SaveToDatabase save_Task = new SaveToDatabase();
//        SendNotification notify_Task = new SendNotification();
//
//        // Create threads for each task
//        Thread save_Thread = new Thread(save_Task);
//        Thread notify_Thread = new Thread(notify_Task);
//
//        // Start the threads
//        save_Thread.start();
//        notify_Thread.start();
//    }
//}