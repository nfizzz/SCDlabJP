
    class SendNotification implements Runnable {
        String category;
        public SendNotification(String Job_Tablename)
        {
            this.category=Job_Tablename;
        }
        @Override
        public void run() {
        Notification_1 ob= new Notification_1(category);
        }
    }