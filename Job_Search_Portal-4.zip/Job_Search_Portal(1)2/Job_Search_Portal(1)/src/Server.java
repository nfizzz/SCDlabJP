import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {
    public static void main(String[] args) throws IOException {
        
        
        Socket socket ;
        InputStreamReader inputStreamReader ;
        OutputStreamWriter outputStreamWriter ;
        BufferedReader bufferedReader ;
        BufferedWriter bufferedWriter ;
        ServerSocket serversocket ;
        serversocket = new ServerSocket(5000);

while (true) {
try {
        socket = serversocket.accept();
        inputStreamReader = new InputStreamReader(socket.getInputStream());
        outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
        bufferedReader = new BufferedReader(inputStreamReader);
        bufferedWriter = new BufferedWriter(outputStreamWriter);


    String msgFromClient =bufferedReader.readLine();
    
    System.out.println("Client:"+msgFromClient);
//  while(true)  
//  {
    if(msgFromClient.equalsIgnoreCase("HELLO") || msgFromClient.equalsIgnoreCase("HI") || msgFromClient.equalsIgnoreCase("Yes") )
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("What kind of Help you need?\nJob Search?\nJob Details?\nEmail Notifications? ");        
        System.out.println("What kind of Help you need?\nJob Search?\nJob Details?\nEmail Notifications? ");
       bufferedWriter.newLine();
       bufferedWriter.flush();
      // break;
    }
    else if(msgFromClient.equalsIgnoreCase("Job Search?") || msgFromClient.equalsIgnoreCase("JOB SEARCH") || msgFromClient.equalsIgnoreCase("job search") )
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("1.How do I search for jobs on the portal?\n Answer: You can use the search bar to enter keywords related to job titles or categories. \n 2.What if I'm not sure about the exact job title? Can I still find relevant opportunities?\n Answer: Absolutely! The search functionality is designed to provide suggestions and match relevant jobs even if you're uncertain about the exact job title.Select specific category button");
      //  bufferedWriter.write("2.What if I'm not sure about the exact job title? Can I still find relevant opportunities?\n Answer: Absolutely! The search functionality is designed to provide suggestions and match relevant jobs even if you're uncertain about the exact job title.Select specific category button");
       // break;
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    else if(msgFromClient.equalsIgnoreCase("Job Details") || msgFromClient.equalsIgnoreCase("job details") || msgFromClient.equalsIgnoreCase("JOB DETAILS") )
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("1.How can I get more details about a specific job listing?\n Answer: Click on explore to view the complete details, including job description, requirements, and application instructions.");
       // bufferedWriter.write("At the time of Ticket Review, if you do not want to do reservation or made a mistake then select the cancel button. ");
       // break;
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    else if(msgFromClient.equalsIgnoreCase("Email Notifications") || msgFromClient.equalsIgnoreCase("Email notifications") || msgFromClient.equalsIgnoreCase("email notification") )
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("1.How do email notifications work for job alerts?\n Answer: The portal will send you email notifications when new jobs matching your criteria are posted.\n 2.What information is included in email notifications for job alerts?\n Answer: Job alert emails typically include details such as the job title, company, and a brief description");
        bufferedWriter.write("You will need to specify the username to whom you want to transfer the amount. ");
       // break;
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    else if(msgFromClient.equalsIgnoreCase("OK")|| msgFromClient.equalsIgnoreCase("OKAY")|| msgFromClient.equalsIgnoreCase("OK,Got it"))
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("AnyThing else?");
        //break;
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    else if(msgFromClient.equalsIgnoreCase("NO"))
    {
        System.out.println("Client:"+msgFromClient);
        bufferedWriter.write("Okay, All the best.");
        //break;
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    if (msgFromClient.equalsIgnoreCase("BYE"))
    { 
        bufferedWriter.write("bye");
        System.out.println("bye");
       bufferedWriter.newLine();
       bufferedWriter.flush();
        //break;
    }
    
  //}

socket.close();
inputStreamReader.close();
outputStreamWriter.close();
bufferedReader.close();
bufferedWriter.close();
}
catch(IOException e)
{
e.printStackTrace();
}


}
}

}


