/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author itsna
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//import java.time.LocalDateTime;  
//import java.time.format.DateTimeFormatter;  
public class TechJobs extends javax.swing.JFrame implements Interface {

    /**
     * Creates new form Jobs
     */
    String Jtitle,Jcategory;
    int d_jobnum1,d_jobnum2,d_jobnum3;
    
    int user_id=1;
    public TechJobs() {
        initComponents();
       retrive_data2();
    }
    public TechJobs(String jobtitle,String Jcategory)
    {
        initComponents();
        this.Jtitle=Jtitle;
        this.Jcategory=Jcategory;
        System.out.println("techjob portal="+this.Jtitle+this.Jcategory);
        retrive_data();
    }

    public void x()
    {
       this.setVisible(true);
    }
    String job_title = ""; // Initialize these variables here
    String c_name = "";
    String location="";
    String job_type="";
    String salary = "";
    String deadline = "";
    String d_jobnum="";

    
    String occupation_1,occupation_2,occupation_3="";
    String companyname_1,companyname_2,companyname_3="";
    String loc_1,loc_2,loc_3="";
    String sal_1,sal_2,sal_3="";
    String dline_1,dline_2,dline_3="";
    String type_1,type_2,type_3="";
   
public void retrive_data() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline,job_num FROM techjobs WHERE Title LIKE '%" + Jtitle + "%'");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                
                
                
                occupation1.setText(job_title);
                companyname1.setText(c_name);
                loc1.setText(location);
                salary1.setText(salary);
                deadline_date1.setText(deadline);
                type1.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
                        
            } else if (rowIndex == 2) {
                
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                
                occupation2.setText(job_title);
                companyname2.setText(c_name);
                loc2.setText(location);
                salary2.setText(salary);
                deadline_date2.setText(deadline);
                type2.setText(job_type);
                 d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                    
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;   
                    
                    
                occupation3.setText(job_title);
                companyname3.setText(c_name);
                loc3.setText(location);
                salary3.setText(salary);
                deadline_date3.setText(deadline);
                type3.setText(job_type);
                 d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
//to display the all type of jobtypes
public void retrive_data2() {
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT Title, company, location, job_type, Salary, deadline,job_num FROM techjobs");

        while (rs.next()) {
            job_title = rs.getString(1);
            c_name = rs.getString(2);
            location = rs.getString(3);
            job_type = rs.getString(4);
            salary = rs.getString(5);
            deadline = rs.getString(6);
            d_jobnum = rs.getString(7);

            // Depending on the row index, assign data to the appropriate text fields
            if (rowIndex == 1) {
                 occupation_1=job_title;
                 companyname_1=c_name;
                 loc_1=location;
                 sal_1=salary;
                 dline_1=deadline;
                 type_1=job_type;
                
                occupation1.setText(job_title);
                companyname1.setText(c_name);
                loc1.setText(location);
                salary1.setText(salary);
                deadline_date1.setText(deadline);
                type1.setText(job_type);
                d_jobnum1=Integer.parseInt(d_jobnum);
                        
            } else if (rowIndex == 2) {
                 occupation_2=job_title;
                 companyname_2=c_name;
                 loc_2=location;
                 sal_2=salary;
                 dline_2=deadline;
                 type_2=job_type;
                

                occupation2.setText(job_title);
                companyname2.setText(c_name);
                loc2.setText(location);
                salary2.setText(salary);
                deadline_date2.setText(deadline);
                type2.setText(job_type);
                 d_jobnum2=Integer.parseInt(d_jobnum);
            }
                else if (rowIndex == 3) {
                 occupation_3=job_title;
                 companyname_3=c_name;
                 loc_3=location;
                 sal_3=salary;
                 dline_3=deadline;
                 type_3=job_type;
                    
                    
                occupation3.setText(job_title);
                companyname3.setText(c_name);
                loc3.setText(location);
                salary3.setText(salary);
                deadline_date3.setText(deadline);
                type3.setText(job_type);
                 d_jobnum3=Integer.parseInt(d_jobnum);
                
            } // Add more conditions for additional rows (salary3, salary4, etc.)

            // You can similarly assign other fields to their respective text fields if needed

            // Increment the row index for the next iteration
            rowIndex++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


//only for testing
public String test_retrive_data(String jt) {
    String company_name="";
    DB_Connectivity db;
    db = DB_Connectivity.getobject();
    Connection con = db.DbConnection();
    int rowIndex = 1; // Initialize a row index to keep track of which row you're processing

    try {
        Statement sm = con.createStatement();
        ResultSet rs = sm.executeQuery("SELECT company FROM techjobs WHERE Title LIKE '%" + jt + "%'");

        while (rs.next()) {
            c_name = rs.getString(1);

        }
        company_name=c_name;
    } catch (Exception e) {
        System.out.println(e);
    }
    return company_name;
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel8 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        penal = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        explorebutton1 = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        occupation1 = new javax.swing.JTextField();
        companyname1 = new javax.swing.JTextField();
        salary1 = new javax.swing.JTextField();
        deadline_date1 = new javax.swing.JTextField();
        type1 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        loc1 = new javax.swing.JTextField();
        Backbutton = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        explorebutton2 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        occupation2 = new javax.swing.JTextField();
        companyname2 = new javax.swing.JTextField();
        salary2 = new javax.swing.JTextField();
        deadline_date2 = new javax.swing.JTextField();
        type2 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        loc2 = new javax.swing.JTextField();
        jPanel16 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        explorebutton3 = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        occupation3 = new javax.swing.JTextField();
        companyname3 = new javax.swing.JTextField();
        salary3 = new javax.swing.JTextField();
        deadline_date3 = new javax.swing.JTextField();
        type3 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        loc3 = new javax.swing.JTextField();
        notification_button = new javax.swing.JButton();

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel19.setText("Software Engineer");

        jLabel20.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 102, 255));
        jLabel20.setText("Pythonleads");

        jLabel21.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(102, 102, 102));
        jLabel21.setText("Islamabad, Pakistan");

        jLabel22.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(102, 102, 102));
        jLabel22.setText("Salary:");

        jLabel23.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(102, 102, 102));
        jLabel23.setText("Deadline:");

        jLabel24.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel24.setText("Rs 70,000 - 100,000 a month");

        jLabel25.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel25.setText("5 April 2023");

        jButton3.setText("Explore");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(0, 153, 153));

        jLabel26.setBackground(new java.awt.Color(0, 0, 0));
        jLabel26.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel26.setText("Full-time");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel26)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(0, 3, Short.MAX_VALUE)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel10.setBackground(new java.awt.Color(0, 153, 153));

        jLabel27.setBackground(new java.awt.Color(0, 153, 102));
        jLabel27.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel27.setText("Remote");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel27)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel22))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addGap(124, 124, 124))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel25)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addGap(21, 21, 21))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(jLabel24))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(1, 1, 1)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton3)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel23)
                                .addComponent(jLabel25))
                            .addGap(26, 26, 26)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        penal.setBackground(new java.awt.Color(0, 51, 51));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        jLabel41.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(102, 102, 102));
        jLabel41.setText("Salary:");

        jLabel42.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(102, 102, 102));
        jLabel42.setText("Deadline:");

        explorebutton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\icons8-forward-button-48.png")); // NOI18N
        explorebutton1.setText("Explore");
        explorebutton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton1ActionPerformed(evt);
            }
        });

        jLabel37.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\location.jpeg")); // NOI18N
        jLabel37.setText("jLabel37");

        occupation1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation1.setText("Software Engineer");
        occupation1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation1ActionPerformed(evt);
            }
        });

        companyname1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname1.setForeground(new java.awt.Color(102, 102, 255));
        companyname1.setText("Pythonleads");
        companyname1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname1ActionPerformed(evt);
            }
        });

        salary1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary1.setText("Rs 70,000 - 100,000 a month");
        salary1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary1ActionPerformed(evt);
            }
        });

        deadline_date1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date1.setText("5 April 2023");

        type1.setBackground(new java.awt.Color(0, 153, 153));
        type1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type1.setText("Full-time");

        jTextField6.setBackground(new java.awt.Color(0, 153, 153));
        jTextField6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField6.setText("Remote");

        loc1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc1.setForeground(new java.awt.Color(102, 102, 102));
        loc1.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel42))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                                .addComponent(loc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(occupation1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel41)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(companyname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton1)))
                .addGap(265, 265, 265))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel41))
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton1))))
                    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel37)
                        .addGroup(jPanel14Layout.createSequentialGroup()
                            .addComponent(companyname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        Backbutton.setBackground(new java.awt.Color(0, 153, 153));
        Backbutton.setText("BACK");
        Backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbuttonActionPerformed(evt);
            }
        });

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        jLabel43.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(102, 102, 102));
        jLabel43.setText("Salary:");

        jLabel44.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(102, 102, 102));
        jLabel44.setText("Deadline:");

        explorebutton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\icons8-forward-button-48.png")); // NOI18N
        explorebutton2.setText("Explore");
        explorebutton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton2ActionPerformed(evt);
            }
        });

        jLabel38.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\location.jpeg")); // NOI18N
        jLabel38.setText("jLabel37");

        occupation2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation2.setText("Software Engineer");
        occupation2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation2ActionPerformed(evt);
            }
        });

        companyname2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname2.setForeground(new java.awt.Color(102, 102, 255));
        companyname2.setText("Pythonleads");
        companyname2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname2ActionPerformed(evt);
            }
        });

        salary2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary2.setText("Rs 70,000 - 100,000 a month");
        salary2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary2ActionPerformed(evt);
            }
        });

        deadline_date2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date2.setText("5 April 2023");

        type2.setBackground(new java.awt.Color(0, 153, 153));
        type2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type2.setText("Full-time");

        jTextField13.setBackground(new java.awt.Color(0, 153, 153));
        jTextField13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField13.setText("Remote");

        loc2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc2.setForeground(new java.awt.Color(102, 102, 102));
        loc2.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel44))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(loc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(occupation2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel43)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(companyname2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton2)))
                .addGap(265, 265, 265))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43))
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton2))))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel38)
                        .addGroup(jPanel15Layout.createSequentialGroup()
                            .addComponent(companyname2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 39, Short.MAX_VALUE))
        );

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));

        jLabel45.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(102, 102, 102));
        jLabel45.setText("Salary:");

        jLabel46.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(102, 102, 102));
        jLabel46.setText("Deadline:");

        explorebutton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\icons8-forward-button-48.png")); // NOI18N
        explorebutton3.setText("Explore");
        explorebutton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                explorebutton3ActionPerformed(evt);
            }
        });

        jLabel39.setIcon(new javax.swing.ImageIcon("C:\\Users\\NOCS\\OneDrive\\Pictures\\location.jpeg")); // NOI18N
        jLabel39.setText("jLabel37");

        occupation3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        occupation3.setText("Software Engineer");
        occupation3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation3ActionPerformed(evt);
            }
        });

        companyname3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        companyname3.setForeground(new java.awt.Color(102, 102, 255));
        companyname3.setText("Pythonleads");
        companyname3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companyname3ActionPerformed(evt);
            }
        });

        salary3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        salary3.setText("Rs 70,000 - 100,000 a month");
        salary3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary3ActionPerformed(evt);
            }
        });

        deadline_date3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        deadline_date3.setText("5 April 2023");

        type3.setBackground(new java.awt.Color(0, 153, 153));
        type3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        type3.setText("Full-time");

        jTextField20.setBackground(new java.awt.Color(0, 153, 153));
        jTextField20.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField20.setText("Remote");

        loc3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        loc3.setForeground(new java.awt.Color(102, 102, 102));
        loc3.setText("Islamabad, Pakistan");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel46))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                                .addComponent(loc3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(type3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(occupation3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel45)
                        .addGap(29, 29, 29))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(companyname3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salary3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(deadline_date3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75)
                        .addComponent(explorebutton3)))
                .addGap(265, 265, 265))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(occupation3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salary3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45))
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(deadline_date3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(type3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(explorebutton3))))
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel39)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(companyname3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(32, 32, 32)
                            .addComponent(loc3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 17, Short.MAX_VALUE))
        );

        notification_button.setText("SET NOTIFICATION");
        notification_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notification_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout penalLayout = new javax.swing.GroupLayout(penal);
        penal.setLayout(penalLayout);
        penalLayout.setHorizontalGroup(
            penalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penalLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(penalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(penalLayout.createSequentialGroup()
                        .addComponent(notification_button)
                        .addGap(463, 463, 463)
                        .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(penalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        penalLayout.setVerticalGroup(
            penalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, penalLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(penalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(notification_button))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(124, 124, 124))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(penal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(penal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void explorebutton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton1ActionPerformed
        // TODO add your handling code here:

        Job_Details d=new Job_Details("Tech & Development",occupation_1,companyname_1,loc_1,sal_1,dline_1,type_1,d_jobnum1);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton1ActionPerformed

    private void BackbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbuttonActionPerformed
        // TODO add your handling code here:
        Search s=new Search();
        s.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackbuttonActionPerformed

    private void occupation1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation1ActionPerformed

    private void companyname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname1ActionPerformed

    private void salary1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary1ActionPerformed

    private void explorebutton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton2ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Tech & Development",occupation_2,companyname_2,loc_2,sal_2,dline_2,type_2,d_jobnum2);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton2ActionPerformed

    private void occupation2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation2ActionPerformed

    private void companyname2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname2ActionPerformed

    private void salary2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary2ActionPerformed

    private void explorebutton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_explorebutton3ActionPerformed
        // TODO add your handling code here:
        Job_Details d=new Job_Details("Tech & Development",occupation_3,companyname_3,loc_3,sal_3,dline_3,type_3,d_jobnum3);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_explorebutton3ActionPerformed

    private void occupation3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation3ActionPerformed

    private void companyname3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companyname3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companyname3ActionPerformed

    private void salary3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary3ActionPerformed

    private void notification_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notification_buttonActionPerformed
        // TODO add your handling code here:
        DB_Connectivity db;
        db = DB_Connectivity.getobject();
        Connection con = db.DbConnection();
//        UserSubscription userSubscription=new UserSubscription(user_id,"technology");
        
        try {
            PreparedStatement pst=con.prepareStatement("INSERT INTO notifi_table (category,email_id,name) VALUES (?,?,?)");
            pst.setString(1,Jcategory);
            pst.setString(2,);        //pass values of actual email_ids and name from login here as well in account and medical 
            pst.setString(3,);
            
                
            pst.executeUpdate();
            System.out.println("User added to notification table");
            
        }catch (Exception e) {
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_notification_buttonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TechJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TechJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TechJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TechJobs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TechJobs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbutton;
    private javax.swing.JTextField companyname1;
    private javax.swing.JTextField companyname2;
    private javax.swing.JTextField companyname3;
    private javax.swing.JTextField deadline_date1;
    private javax.swing.JTextField deadline_date2;
    private javax.swing.JTextField deadline_date3;
    private javax.swing.JButton explorebutton1;
    private javax.swing.JButton explorebutton2;
    private javax.swing.JButton explorebutton3;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField loc1;
    private javax.swing.JTextField loc2;
    private javax.swing.JTextField loc3;
    private javax.swing.JButton notification_button;
    private javax.swing.JTextField occupation1;
    private javax.swing.JTextField occupation2;
    private javax.swing.JTextField occupation3;
    private javax.swing.JPanel penal;
    private javax.swing.JTextField salary1;
    private javax.swing.JTextField salary2;
    private javax.swing.JTextField salary3;
    private javax.swing.JTextField type1;
    private javax.swing.JTextField type2;
    private javax.swing.JTextField type3;
    // End of variables declaration//GEN-END:variables
}
