
public class Validation  {
    String title,company_name,location,Job_type,Salary,Deadline,Description,Responsibility;
    String education,skills,exprience,instructions,Job_Tablename,JobDesc_Tablename;
    Validation(JobPost2 jobPost2Instance)
    {

        String education = jobPost2Instance.get_education();
        String skills = jobPost2Instance.get_skills();
        String exprience = jobPost2Instance.get_exprience();
        String instructions = jobPost2Instance.get_instructions();
     
    }
public boolean validateFields(JobPost2 jobPost2Instance)
{
    boolean x= false;
    if(education.equals("") && skills.equals("") && exprience.equals("") && instructions.equals(""))
        {
            jobPost2Instance.ifoption1();
        }
        else if(education.equals(""))
        {
            jobPost2Instance.ifoption2();  
        }
        else if(skills.equals(""))
        {
            jobPost2Instance.ifoption3(); 
        }
        else if(exprience.equals(""))
        {
            jobPost2Instance.ifoption4();   
        }
        else if(instructions.equals(""))
        {
            jobPost2Instance.ifoption5();    
        }
      if(!education.equals("") && !skills.equals("") && !exprience.equals("") && !instructions.equals(""))
    {
        x= true;   
    }
      return x;
}
}
