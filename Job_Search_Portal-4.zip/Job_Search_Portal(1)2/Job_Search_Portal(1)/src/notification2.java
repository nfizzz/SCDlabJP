
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

//import javax.mail.*;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
import java.util.Properties;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.SimpleEmail;


public class notification2 {
    String Notifi_Table,N_Category;
    public notification2(String Job_Tablename)
    {
        this.N_Category=Job_Tablename;
       // N_Category="techjobs";
//        if("techjobs".equals(N_Category))
//        {
//            
//        }
//        else if("accountjobs".equals(N_Category))
//        {
//            
//        }
//        else if("medicaljobs".equals(N_Category))
//        {
//            
//        }
      retrive_data(N_Category);
    }
    public void retrive_data(String Notifi_Table)
    {
          DB_Connectivity db;
          db = DB_Connectivity.getobject();
          Connection con = db.DbConnection();
          try {
          Statement sm = con.createStatement();
          ResultSet rs = sm.executeQuery("SELECT email_id FROM Notifi_Table WHERE category = '" + N_Category + "'");
          
          // Traverse the result set
            while (rs.next()) {
                // Retrieve and print the email ID
                String email_id = rs.getString("email_id");
                System.out.println("Email ID: " + email_id);
                
                EmailSender(email_id);
                
            }
          }
          catch(Exception e)
         {
          System.out.println(e);
         }
    }
    
public void EmailSender(String email_id) {
    try {
    Email email = new SimpleEmail();
        email.setHostName("smtp.gmail.com");
        email.setSmtpPort(587);
        email.setAuthenticator(new DefaultAuthenticator("aimannajeeb1122@gmail.com", "AimanNajeeb0192"));
        email.setStartTLSRequired(true);
        email.setFrom("aimannajeeb1122@gmail.com");
        email.setSubject("New job Notification");
        email.setMsg("This is a test email sent from Java.");
        email.addTo(email_id);
        email.send();

        System.out.println("Email sent successfully!");}
  catch (Exception e) {
        e.printStackTrace();
    }

//        // Sender's email credentials
//        final String senderEmail = "aimannajeeb1122@gmail.com";
//        final String senderPassword = "AimanNajeeb0192";
//
//        // Recipient's email address
//        String to = email_id;
//
//        // Email server properties
//        Properties props = new Properties();
//        props.put("mail.smtp.host", "smtp.gmail.com");
//        props.put("mail.smtp.port", "587");
//        props.put("mail.smtp.auth", "true");
//        props.put("mail.smtp.starttls.enable", "true");
//
//        // Authenticator to provide credentials for sending emails
//        Authenticator authenticator = new Authenticator() {
//            protected PasswordAuthentication getPasswordAuthentication() {
//                return new PasswordAuthentication(senderEmail, senderPassword);
//            }
//        };
//
//        // Create a Session instance with the specified properties and authenticator
//        Session session = Session.getInstance(props, authenticator);
//
//        try {
//            // Create a MimeMessage object
//            Message message = new MimeMessage(session);
//
//            // Set the sender's email address
//            message.setFrom(new InternetAddress(senderEmail));
//
//            // Set the recipient's email address
//            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
//
//            // Set the email subject
//            message.setSubject("New job Notification");
//
//            // Set the email body
//            message.setText("This is a test email sent from Java.");
//
//            // Send the email
//            Transport.send(message);
//
//            System.out.println("Email sent successfully!");
//
//        } catch (MessagingException e) {
//            e.printStackTrace();
//        }
    }public static void main(String[] args)
{
    notification2 ob= new notification2("techjobs");
    
}
}

    

