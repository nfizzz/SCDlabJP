
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

//import javax.mail.*;
//import javax.mail.internet.*;
//import java.util.Properties;

import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;

public class notification3 {
    String Notifi_Table,N_Category;
    public notification3(String Job_Tablename)
    {
        this.N_Category=Job_Tablename;
       // N_Category="techjobs";
      retrive_data(N_Category);
    }
    
        public void retrive_data(String Notifi_Table)
    {
          DB_Connectivity db;
          db = DB_Connectivity.getobject();
          Connection con = db.DbConnection();
          try {
          Statement sm = con.createStatement();
          ResultSet rs = sm.executeQuery("SELECT email_id FROM Notifi_Table WHERE category = '" + N_Category + "'");
          
          // Traverse the result set
            while (rs.next()) {
                // Retrieve and print the email ID
                String email_id = rs.getString("email_id");
                System.out.println("Email ID: " + email_id);
                
//                EmailSender(email_id);
// Send email using Gmail API
//                sendEmail(email_id);
                sendEmail(email_id, "Subject", "Body");
            }
          }
          catch(Exception e)
         {
          System.out.println(e);
         }
    }
        
//        private void sendEmail(String recipientEmail) {
//        // Replace these with your actual Gmail API credentials
//        String APPLICATION_NAME = "YourAppName";
//        String CREDENTIALS_FILE_PATH = "path/to/your/credentials.json";
//
//        try {
//            // Set up Gmail API
//            Gmail service = GmailAPISender.getGmailService(APPLICATION_NAME, CREDENTIALS_FILE_PATH);
//
//            // Compose and send an email
//            String subject = "Subject";
//            String bodyText = "Body of the email";
//            GmailAPISender.sendMessage(service, "your@gmail.com", recipientEmail, subject, bodyText);
//
//        } catch (Exception e) {
//            System.out.println("Error sending email: " + e.getMessage());
//        }
        
            public void sendEmail(String to, String subject, String body) {
        try {
            Gmail service = getGmailService();

            // Create the MimeMessage
            Message message = createMessage("your_email@gmail.com", to, subject, body);

            // Send the email
            service.users().messages().send("your_email@gmail.com", message).execute();
        } catch (Exception e) {
            System.out.println("Error sending email: " + e.getMessage());
        }
    }

    private static Gmail getGmailService() throws GeneralSecurityException, IOException {
       // The JSON file containing your Gmail API credentials

    }

    private static Message createMessage(String from, String to, String subject, String body) throws IOException {
        // Create a new Message object
        Message message = new Message();

        // Create email headers
        StringBuilder headers = new StringBuilder();
        headers.append("From: ").append(from).append("\r\n");
        headers.append("To: ").append(to).append("\r\n");
        headers.append("Subject: ").append(subject).append("\r\n\r\n");

        // Convert email headers and body to base64
        String emailContent = headers.toString() + body;
        byte[] bytes = Base64.encodeBase64URLSafe(emailContent.getBytes());
        String encodedEmail = new String(bytes);

        // Set the raw content of the message
        message.setRaw(encodedEmail);

        return message;
    }
}
        
        
        

