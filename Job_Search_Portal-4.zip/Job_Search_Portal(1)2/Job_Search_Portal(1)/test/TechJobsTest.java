/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author NOCS
 */
public class TechJobsTest {
    
    public TechJobsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of retrive_data method, of class TechJobs.
     */
    @Test
    public void testRetrive_data() {
        System.out.println("Company name_retrive_data test");
        String job_title="Frontend Developer";
        TechJobs ob = new TechJobs();
        String expected_company="VentureDive";
        assertEquals(expected_company, ob.test_retrive_data(job_title));
      
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    

    
}
