import java.sql.Connection;
import java.sql.DriverManager;

public class DB_Connectivity {
   Connection con;
    public Connection DbConnection()
  {
    
    try{  
          Class.forName("com.mysql.jdbc.Driver");
         try { 
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/job","root","");
             System.out.println("connected to db");
         }catch(Exception e){
             System.out.println(e);}
    }catch(Exception e)
    { System.out.println(e);
    }  
    return con;
  }
} 
    

