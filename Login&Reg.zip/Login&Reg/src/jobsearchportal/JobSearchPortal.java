
package jobsearchportal;


public class JobSearchPortal {

   
    public static void main(String[] args) {
        // TODO code application logic here
       Login LoginFrame = new Login();
       LoginFrame.setVisible(true);
       LoginFrame.pack();
       LoginFrame.setLocationRelativeTo(null);
    }
    
}
